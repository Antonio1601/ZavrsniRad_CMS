<?php include 'includes/header.php';?>
        <!-- Navigation Bar -->
   <?php include 'includes/navbar.php';?>
        <!-- Navigation Bar -->

    <div class="container">
        <div class="row">
	        <!-- Page Content -->
	        <div class="col-md-8">
            <h1 class="page-header">O | Nama </h1>
            Dobrodošli!
            <br>
            Ova aplikacija je sustav za obvjavljivanje vijesti iz svijeta filma koji korisnicima omogućuje objavljivanje i upravljanje raznim vrstama sadržaja.
            Ili ukratko, CMS.
            <br><br><br>




           
           Glavne značajke:
           <br><br>
           # Višestruki korisnički pristup: omogućuje prijavu više vrsta korisnika <br>
           # Funkcionalna administrativna ploča: omogućuje svim administratorima da pravilno upravljaju svojim sadržajem pomoću administrativne ploče  <br>
           # CRUD funkcionalnost: omogućuje svim korisnicima stvaranje, čitanje, ažuriranje i brisanje sadržaja u upravljanom formatu <br>
           # Opcija ažuriranja profila: omogućuje korisnicima ažuriranje podataka o profilu/računu <br>
           # Sigurna registracija i opcija prijave za korisnike <br>
           # Najnovije vijesti: omogućuje korisniku pregled svih vijesti iz svijeta filma u trendu <br> 
           <br><br><br>

           Korišteni alati: 
           <br><br>
           #Front-End:  HTML, CSS <br>
           #Back-End:   PHP       <br>
           #Baza podataka:   MySQL     <br>
           <br><br><br>

           Aplikaciju razvio: <br><br>
           Ime: Antonio Santi <br>
           Email: antonio.santi7@hotmail.com <br>
           <br>
           <br>
           <br>



        </div>

             <div class="col-md-4">

               <?php include 'includes/sidebar.php';
?><!-- Footer -->
</div>
</div>
</div>
  <script src="js/jquery.js"></script>
  <script src="js/bootstrap.min.js"></script>

</body>
</html>